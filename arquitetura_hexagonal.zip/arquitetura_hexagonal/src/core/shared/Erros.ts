const Erros = {
    USUARIO_JA_EXISTE: 'USUARIO_JA_EXISTE'
} as const

export default Erros