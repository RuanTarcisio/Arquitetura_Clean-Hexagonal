import dotenv from 'dotenv'
dotenv.config()

import menuPrincipal from "./app/menu/menuPrincipal"
menuPrincipal()
