export default interface Produto {
    id?: string
    nome: string
    preco: number
    consultadoPor: string
}